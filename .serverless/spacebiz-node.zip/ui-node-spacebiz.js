
function getTender() {
	tenderObj = {
		"budget": 3000,
		"tonnage": 3000,
		"quantity": 1
	}
	
	return tenderObj
}

console.log(module);

console.log(getTender());