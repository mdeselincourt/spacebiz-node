const serverlessMod = require('serverless-http')
const expressMod = require('express')
const spacebiz = expressMod()

spacebiz.get("/", (req,res) => {
	console.log("Handling GET /");
	res.send("Hello world");
})

module.exports.handler = serverlessMod(spacebiz);

console.log("node-backend-entrypoint-spacebiz loaded");